import * as d3 from 'd3';
import '../style/mainViz.css';
import textures from 'textures';

function dotsGroup(_){

  let _w;
  let _h;
  let _color;
  let radiusScale;
  let tooltip;
  let _forceX;
  let _forceY;
  // let force;
  let _forceManyBody;
  let _strength;
  let _mapRadius;
  let _radius;

  let eventsData;
  let filterData;


  //Force layout related
	const force = d3.forceSimulation();
	//Define some forces
	// const collide = d3.forceCollide().radius(d => d.r + 2);
  const forceCollide = d3.forceCollide()
  .radius(function(d){
    if (d.killed_injured > 46){
      return 48
    }
    if (d.killed_injured == 0){
      return 3.5
    }
    else {
      return radiusScale(d.killed_injured)+3
  }
  })
  .iterations(1);

  // const forceCollide = d3.forceCollide()
  // .radius(function(d){
  //   return radiusScale(d.killed_injured)+2
  // })
  // .iterations(1);

	const radial = d3.forceRadial();


 //define projection
  const scaleSqrt = d3.scaleSqrt()
  const projection = d3.geoMercator()
    .scale(100)
    .center([300, 80]);//???


function exports(firedata){

   _w = _.clientWidth/2;
   _h = _.clientHeight;

   // define colorScale
  //  var colorScale= d3.scaleLinear()
  //  .domain([3,6,9,12])
  //  .range(["#008753","#ddceba","#22326e"]);
    //  .domain([1996,2006,2016])
    //  .range(["#827370","#d4d5d4","#c21807"]);

  //  _color = d3.scaleOrdinal(d3.schemeCategory20c);

  function myFill(d) {
            if(d.month == 1){return '#372328'}
            if(d.month == 2){return '#372328'}
            if(d.month == 12){return '#372328'}
            if(d.month == 3){return "#25364e"}
            if(d.month == 4){return "#25364e"}
            if(d.month == 5){return "#25364e"}
            if(d.month == 6){return "#255a3b"}
            if(d.month == 7){return "#255a3b"}
            if(d.month == 8){return "#255a3b"}
            else{return "#d8c6b0";}
        }

    //define radiusScale
   _mapRadius=[1,25]

  radiusScale = d3.scaleSqrt()
       .domain([1,46])
       .range(_mapRadius);

   // import and manipulate data
     eventsData = firedata.map(fire => {
       const [x,y] = projection([fire.longtitude, fire.latitude]);
       return {
         x,
         y,
         ...fire
       }
     });
     filterData = eventsData.filter(function(d){return d.type =='住宅';});
  console.log(eventsData);
    console.log(filterData);


  //append circles
   const root = d3.select(_);

   let svg = root
      .selectAll('.dots-group-svg')
      .data([1]);

   svg = svg.enter().append('svg')
      .attr('class','dots-group-svg')
      .merge(svg)
      .attr('width',_w)
      .attr('height',_h)
      .style('position','absolute');



  //Draw the states to <svg>
  		const dotsNodes = svg.selectAll('.events')
  			.data(filterData,d => d.id);


  		const dotsNodesEnter = dotsNodes.enter()
  			.append('g')
  			.attr('class','events');

      _color = function(d,i){return myFill(d);};
      _radius = function(d){
          if (d.killed_injured > 46){
            return 45
          }
          if (d.killed_injured == 0){
            return 0.5
          }
          else {
            return radiusScale(d.killed_injured)
        }
      };

      // _radius = function(d){
      //       return radiusScale(d.killed_injured)
      // };

// dotsNodesEnter.append('text').text(d => d.state);


  //add textures, tooltip and highlight to circles
  		dotsNodesEnter
        .append('circle')
        .attr('class','dots_group')
        .attr('r',_radius)
        .style('fill',_color)
        .classed('active',false)
        .on('click', function(d, i){
          const isActive = d3.select(this).classed('active');
          console.log(isActive);
          let t = textures.lines()
              .size(6)
              .stroke('white')
              // .background(function(d) {
              //   if (d.success == '0'){return '#827370'}
              //   else {return myFill(d);}
              //   })
              .background(myFill(d))
              .strokeWidth(3);

          svg.call(t);

          if (isActive === false){
            d3.select(this)
          .style('fill',t.url());

          d3.select(this).classed('active',true)
        } else {
          d3.select(this)
        .style('fill',_color);

        d3.select(this).classed('active',false)
        }

        })

        .on("mouseover", function(d) {
            d3.select(this)
            .attr("stroke", "#000")
            .attr("stroke-width",3);

              tooltip= d3.select('.tooltip');
                tooltip.transition()
                       .style('opacity',0.8)
                       .style("left", (d.x + 100) + "px")
                       .style("top", (d.y+500) + "px")
                       .style("display", "block")
                       .style("pointer-events", "none");

                    tooltip
                            .select('.tipProvince')
                            .text(d.killed_injured);
                    tooltip
                            .select('.tipDate')
                            .text(d.year+ '/' + d.month + '/' + d.day);
                    // tooltip
                    //         .select('.tipAttack')
                    //         .text("ATTACK TYPE: " + d.attacktype);
                    // tooltip
                    //         .select('.tipTarget')
                    //         .text("TARGET/VICTIM TYPE: " + d.target1);
                    // tooltip
                    //         .select('.tipNkill')
                    //         .text("TOTAL NUMBER OF FATALITIES: " + d.nkill);
                    // tooltip
                    //         .select('.tipNwound')
                    //         .text("TOTAL NUMBER OF INJURED: " + d.nwound);
                        })

          .on("mouseout", function(d,i) {
          tooltip.transition()
                 .style('opacity',0);
                 d3.select(this)
                 .attr("stroke-width",0);
        //  d3.select(this)
        //    .style('fill',function(d,i){return _color(i)} );
          });


  		const bubbles = dotsNodesEnter
  			.merge(dotsNodes)
        .attr('transform', d => `translate(${d.x}, ${d.y})`);




       radial
       			.x(_w/2)
       			.y(_h/2)
       			.radius(10);

       		force //the simulation
       			.force('collide',forceCollide) //
       			.force('radial',radial)
       			.alpha(1)
       			.on('tick',tick)
       			.nodes(filterData);



      //  //add state names to each circle group
      //  statesMap.forEach(function(value,key) {
      //    svg.append("text")
      //     .attr("class","dotsExplanation")
      //     .attr("x",value.x )
      //     .attr("y",value.y + 50)
      //     .attr("text-anchor","middle")
      //     .style("font-family","futura")
      //     .style('opacity',0)
      //     .style('font-size',12)
      //     .text(key);
       //
      //  });


       function tick(){
        //  console.log('tick');
         bubbles
         .attr('transform', d => `translate(${d.x}, ${d.y})`);
       }


}

exports.mapRadius = function(_){
  if(typeof _ ==='undefined') return _mapRadius;
  _mapRadius = _;
  return this;
}

exports.forceManyBody = function(_){
  if(typeof _ ==='undefined') return _forceManyBody;
  _forceManyBody = _;
  return this;
}

exports.strength = function(_){
  if(typeof _ ==='undefined') return _strength;
  _strength = _;
  return this;
}

exports.forceX = function(_){
  if(typeof _ ==='undefined') return _forceX;
  _forceX = _;
  return this;
}

exports.forceX = function(_){
  if(typeof _ ==='undefined') return _forceX;
  _forceX = _;
  return this;
}

exports.forceY = function(_){
  if(typeof _ ==='undefined') return _forceY;
  _forceY = _;
  return this;
}

// exports.timelinePosition= function(_){
//   if(typeof _ ==='undefined') return _position;
//   _position = _;
//   return this;
// }

// exports.restart = function(){
//   force
//     .stop()
//     .force("x",_forceX)
//     .force("y",_forceY)
//     .alpha(1)
//     .restart();
//   return this;
// }
//
// exports.stop = function(){
//   force
//     .stop();
//   return this;
// }


exports.changeColor = function(){
  if(typeof _ ==='undefined') return _color;
  _color = _;
  return this;
}
  return exports;

}

export default dotsGroup;
