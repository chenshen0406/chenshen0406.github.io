version v1.2.0
--------------
  * MercatorMalaysia added
  * MercatorEquatorialGuinea added

version v1.1.0
--------------
  * *fitExtent* and *fitSize* added to all projections

version v1.0.0
--------------
  * All the library changed to make it d3 4.0 compatible
  * Tests aren't done with moka but with tape
  * Gulp isn't used anymore ([read here why](https://bost.ocks.org/mike/d3-plugin/))
  * getCompositionBorders is only practical with SVG, so a drawCompositionBorders has been added to use Canvas without using Canvas2D, not always available
  * albersUsaTerritories projection added

version v0.4.0
--------------
  * mercatorEcuador projection added
  * transverseMercatorChile projection added

version v0.3.0
--------------
  * conicEquidistantJapan projection added
  * All projections are now available separately and minified
  * Newer packages at package.json
  * Integration with travis.io

version v0.2.0
--------------
  * conicConformalEurope projection added

version v0.1.0
--------------
  * Spain moved to the upper-left corner
  * Portugal moved to the upper-left corner
  * France moved to the upper-left corner
